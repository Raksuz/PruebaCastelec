package com.prueba.castelec.crudproductos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudproductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudproductosApplication.class, args);
	}

}
